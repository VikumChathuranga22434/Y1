#include <stdio.h>

// counter cotroll repitition
int main ()
{
	int counter = 1; //initialize
	
	while (counter <= 10) // repitition condition 
	{
		printf ("%d", counter); // display count 
		++counter; //increment 
	} // end the while 
	
	return 0;
}// end of main function


