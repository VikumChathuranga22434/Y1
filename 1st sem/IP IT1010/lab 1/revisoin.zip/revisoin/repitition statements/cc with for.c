#include <stdio.h>

// cc repitition with for statement

int main()
{
	int counter = 1;
	
	for (counter = 1; counter <= 10; ++counter)
	{
		printf ("%d", counter);
	}
	
	return 0;
}

