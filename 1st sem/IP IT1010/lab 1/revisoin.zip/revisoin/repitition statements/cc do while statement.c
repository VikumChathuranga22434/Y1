#include <stdio.h>

// do while statement 

int main ()
{
	int x = 1;
	
	/*do
	{
		printf ("%d", x);
		++x;
		
	}while(x <= 10);*/
	
	do
	{
		printf ("%d", x);
		//++x;
		
	}while(++x <= 10);
	
	
	return 0;
}
