#include <stdio.h>

//Exercise 3 in lectre slide 5

int main()
{
	int x;
	
	for(x = 3; x < 24; x += 5)
	{
		printf ("%d,", x);
	}
	
	return 0;
}
