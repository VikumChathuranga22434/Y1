#include <stdio.h>

int main()
{
	int x = 0, y;
	
	while(x <= 20)
	{
		y = x;
		
		printf ("%d", y);
		x += 2;
	}
	
	return 0;
}
