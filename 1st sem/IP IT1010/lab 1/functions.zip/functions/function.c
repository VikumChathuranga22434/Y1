#include <stdio.h>
#include <math.h>

// Function
/*
int main()
{
	printf ("%.2f\n", sqrt (900.00));
	printf ("%.2f\n", pow (3, 2));
	printf ("%.2f\n", exp (1));
	printf ("%.2f\n", log (10));
	printf ("%.2f\n", ceil(9.2));
	printf ("%.2f\n", floor(9.2));
	
	return 0;
}*/
/*
int main ()
{
	int x; 
	
	printf ("%.2f\n", floor (7.5));
	printf ("%.2f\n", floor (0.0));
	printf ("%.2f\n", ceil (-6.5));
	printf ("%.2f\n", pow (5, 2));
	
	return 0;
}*/
