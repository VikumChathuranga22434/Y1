#include <stdio.h>

int main(void){
	
	printf("=============== \n""Name" "\tSubject \n" "=============== \n" "Amal" "\tEnglish \n" "Mali" "\tSinhala \n" "Nipun" "\tHistory \n");
	
	return 0;
} 
