//C program about my name,DOB and Student ID
#include <stdio.h>

int main(void){
	
	printf("Name: Thirasara Dewmin \n" "DOB: Dec 12, 2001 \n" "ID: IT22100016 \n" );
	
	return 0;
}

