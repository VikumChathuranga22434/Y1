#include <stdio.h>
int main(void)
{
	/*Display "My First C Program'
	The words are separated by tab */
	
	printf("My\tFirst\tc\tprogram\n");
	
	return 0;
}//end of function main
