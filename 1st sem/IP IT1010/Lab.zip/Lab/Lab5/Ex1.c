//This program displays number from 1 to 4
#include <stdio.h>
int main(void)
{
	int count = 1;
	
	while(count <= 4)
	{
		printf("%d\t", count);
		count++;
	}
	
	return 0;
}
