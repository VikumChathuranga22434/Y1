//This program displays numbers from 1 to 4
#include <stdio.h>
int main(void)
{
	int count;
	
	for(count = 1; count <= 4; count++)
	{
		printf("%d\t", count);
	}
	return 0;
}
